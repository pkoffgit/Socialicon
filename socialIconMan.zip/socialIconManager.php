<?php
/*
Plugin Name: Social Media Manager
Description: Add social media icons to posts.
Version: 1.0
Author: Your Name
*/

// Hook into the content and add social media icons
function add_social_media_icons($content) {
    $icons_html = '<div class="social-icons">
                    <a href="#" target="_blank"><img src="facebook-icon.png" alt="Facebook"></a>
                    <a href="#" target="_blank"><img src="twitter-icon.png" alt="Twitter"></a>
                    <a href="#" target="_blank"><img src="instagram-icon.png" alt="Instagram"></a>
                </div>';

    return $content . $icons_html;
}

add_filter('the_content', 'add_social_media_icons');
?>
